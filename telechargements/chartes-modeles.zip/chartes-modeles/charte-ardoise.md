# Charte graphique · modèle « Ardoise »

Charte de l'application, à respecter dans chaque écran. Modèle du cours, à adapter à l'entreprise.

## Esprit

Sobre et rassurante, pour une entreprise de services ou industrielle.

## Couleurs

- **Principale** : #1F3A5F (en-tête, bouton principal)
- **Secondaire** : #3D7EA6 (liens, onglets actifs)
- **Accent** : #F2A541 (alertes, chiffres clés)
- **Fond** : #F5F7FA (fond des écrans)
- **Texte** : #1E1E1E (texte courant)

## Polices

- Titres : Poppins
- Texte : Inter
- Les deux polices sont gratuites, sur Google Fonts.

## Ton

Direct et précis, vouvoiement.

## Composants

- Un seul bouton principal par écran, dans la couleur principale.
- Boutons secondaires : fond blanc, bordure de la couleur secondaire.
- Cartes : fond blanc, coins arrondis de 12 px, ombre légère.
- Tableaux : en-tête dans la couleur de fond, lignes séparées par un trait fin.
- Texte courant en 16 px au moins ; contraste suffisant entre texte et fond.

## Logo

[Décrivez ici le logo de l'entreprise : forme, couleurs, où le trouver. Claude ne voit pas une image jointe dans un PDF.]
