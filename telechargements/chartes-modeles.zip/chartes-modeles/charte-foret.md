# Charte graphique · modèle « Forêt »

Charte de l'application, à respecter dans chaque écran. Modèle du cours, à adapter à l'entreprise.

## Esprit

Naturelle et engagée, pour une entreprise qui met en avant ses engagements.

## Couleurs

- **Principale** : #2D6A4F (en-tête, bouton principal)
- **Secondaire** : #95D5B2 (étiquettes, onglets)
- **Accent** : #F4A261 (alertes, chiffres clés)
- **Fond** : #F6FBF7 (fond des écrans)
- **Texte** : #1B1B1B (texte courant)

## Polices

- Titres : Nunito
- Texte : Nunito Sans
- Les deux polices sont gratuites, sur Google Fonts.

## Ton

Calme et positif, vouvoiement.

## Composants

- Un seul bouton principal par écran, dans la couleur principale.
- Boutons secondaires : fond blanc, bordure de la couleur secondaire.
- Cartes : fond blanc, coins arrondis de 12 px, ombre légère.
- Tableaux : en-tête dans la couleur de fond, lignes séparées par un trait fin.
- Texte courant en 16 px au moins ; contraste suffisant entre texte et fond.

## Logo

[Décrivez ici le logo de l'entreprise : forme, couleurs, où le trouver. Claude ne voit pas une image jointe dans un PDF.]
