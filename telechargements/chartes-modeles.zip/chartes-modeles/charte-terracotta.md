# Charte graphique · modèle « Terracotta »

Charte de l'application, à respecter dans chaque écran. Modèle du cours, à adapter à l'entreprise.

## Esprit

Chaleureuse et artisanale, pour une marque de produits ou un commerce.

## Couleurs

- **Principale** : #B5543A (en-tête, bouton principal)
- **Secondaire** : #2A3D45 (titres, menu)
- **Accent** : #E9C46A (alertes, chiffres clés)
- **Fond** : #FBF7F2 (fond des écrans)
- **Texte** : #222222 (texte courant)

## Polices

- Titres : DM Serif Display
- Texte : Source Sans 3
- Les deux polices sont gratuites, sur Google Fonts.

## Ton

Chaleureux et simple, vouvoiement.

## Composants

- Un seul bouton principal par écran, dans la couleur principale.
- Boutons secondaires : fond blanc, bordure de la couleur secondaire.
- Cartes : fond blanc, coins arrondis de 12 px, ombre légère.
- Tableaux : en-tête dans la couleur de fond, lignes séparées par un trait fin.
- Texte courant en 16 px au moins ; contraste suffisant entre texte et fond.

## Logo

[Décrivez ici le logo de l'entreprise : forme, couleurs, où le trouver. Claude ne voit pas une image jointe dans un PDF.]
