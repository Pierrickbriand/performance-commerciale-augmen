# Charte graphique · modèle « Néon »

Charte de l'application, à respecter dans chaque écran. Modèle du cours, à adapter à l'entreprise.

## Esprit

Moderne et technologique, pour une start-up ou une entreprise du numérique.

## Couleurs

- **Principale** : #5B21B6 (en-tête, bouton principal)
- **Secondaire** : #06B6D4 (liens, onglets actifs)
- **Accent** : #F43F5E (alertes, chiffres clés)
- **Fond** : #F8FAFC (fond des écrans)
- **Texte** : #0F172A (texte courant)

## Polices

- Titres : Space Grotesk
- Texte : Inter
- Les deux polices sont gratuites, sur Google Fonts.

## Ton

Dynamique et concis, tutoiement possible si l'entreprise le pratique.

## Composants

- Un seul bouton principal par écran, dans la couleur principale.
- Boutons secondaires : fond blanc, bordure de la couleur secondaire.
- Cartes : fond blanc, coins arrondis de 12 px, ombre légère.
- Tableaux : en-tête dans la couleur de fond, lignes séparées par un trait fin.
- Texte courant en 16 px au moins ; contraste suffisant entre texte et fond.

## Logo

[Décrivez ici le logo de l'entreprise : forme, couleurs, où le trouver. Claude ne voit pas une image jointe dans un PDF.]
